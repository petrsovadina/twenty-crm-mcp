# Contributing to Twenty CRM MCP Server

Thank you for your interest in contributing! This project aims to provide the best possible integration between Twenty CRM and MCP-compatible AI assistants.

## Development Setup

1. **Fork and clone the repository**:
```bash
git clone https://github.com/abugodev/twenty-crm-mcp.git
cd twenty-crm-mcp
```

2. **Install dependencies**:
```bash
npm install
```

3. **Set up environment variables**:
```bash
cp .env.example .env
```
Edit `.env` with your Twenty CRM API key and base URL.

4. **Test your setup**:
```bash
npm start
```

## How to Contribute

### Reporting Issues

Before creating an issue, please:

1. **Search existing issues** to avoid duplicates
2. **Include relevant details**:
   - Twenty CRM version (cloud/self-hosted)
   - Node.js version
   - Error messages and stack traces
   - Steps to reproduce

### Suggesting Features

We welcome feature suggestions! Please:

1. **Open a discussion** before submitting large features
2. **Explain the use case** and expected behavior
3. **Consider backward compatibility**

### Code Contributions

#### Development Guidelines

**Code Style**:
- Use ES modules (`import`/`export`)
- Follow existing naming conventions
- Add JSDoc comments for new functions
- Keep functions focused and small

**Error Handling**:
- Always handle API errors gracefully
- Provide helpful error messages to users
- Log errors with appropriate context

#### Pull Request Process

1. **Create a feature branch**:
```bash
git checkout -b feature/your-feature-name
```

2. **Make your changes** following the coding guidelines

3. **Test thoroughly**

4. **Commit with clear messages**:
```bash
git commit -m "feat: add support for custom field types"
```

Use conventional commit format:
- `feat:` for new features
- `fix:` for bug fixes
- `docs:` for documentation changes
- `refactor:` for code refactoring

5. **Push and create PR**:
```bash
git push origin feature/your-feature-name
```

## Roadmap

### Planned Features

- Bulk Operations: Import/export large datasets
- Advanced Filtering: Complex query capabilities
- Webhook Support: Real-time notifications
- TypeScript Support: Full type definitions
- Additional Object Types: Support for opportunities, custom objects

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow

Thank you for helping make this project better!
